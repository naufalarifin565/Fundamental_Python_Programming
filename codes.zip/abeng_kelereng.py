m=int(input())
n=int(input())
if(m%(n+1)==0):
    print("abeng")
else:
    print("bahresi")


